param([Parameter(Mandatory)][string]$Repository)
$ErrorActionPreference='Stop'
$repo=[IO.Path]::GetFullPath($Repository)
$run=Join-Path $repo 'work/checkpoint-7.24c/logbook-closeout-20260930'
$sourceFiles=@(foreach($top in @('src','tests','scripts','packaging')){
  foreach($f in Get-ChildItem -LiteralPath (Join-Path $repo $top) -File -Recurse){
    $relative=[IO.Path]::GetRelativePath($repo,$f.FullName).Replace('\','/')
    if($relative -match '/(bin|obj|node_modules|__pycache__)/'){continue}
    [pscustomobject]@{path=$relative;sha256=(Get-FileHash -LiteralPath $f.FullName).Hash;bytes=$f.Length}
  }
})|Sort-Object path
$sourceJson=$sourceFiles|ConvertTo-Json -Depth 4
$sourceHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($sourceJson)))
$id='S4-7.24C-FINAL-L1-20260930-'+$sourceHash.Substring(0,12).ToLowerInvariant()
$target=Join-Path $repo ('outputs/Alpha6OPS-Desktop-'+$id)
if(Test-Path -LiteralPath $target){throw 'Frozen target exists; never overwrite.'}
New-Item -ItemType Directory -Path $target|Out-Null
$sourceJson|Set-Content -LiteralPath (Join-Path $target 'source-manifest.json') -Encoding utf8
$sourceZip=[IO.Compression.ZipFile]::Open((Join-Path $target 'source-snapshot.zip'),[IO.Compression.ZipArchiveMode]::Create)
try{foreach($f in $sourceFiles){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($sourceZip,(Join-Path $repo $f.path),$f.path,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}}finally{$sourceZip.Dispose()}
$publish=Join-Path $repo 'outputs/Alpha6OPS-Desktop-0.22.0'
$portable=Join-Path $target 'portable'
Copy-Item -LiteralPath $publish -Destination $portable -Recurse
$installer=Join-Path $target 'Alpha6OPS-Setup-0.22.0-7.24C-FINAL-L1.exe'
$zip=Join-Path $target 'Alpha6OPS-Desktop-0.22.0-7.24C-FINAL-L1-win-x64.zip'
Copy-Item -LiteralPath (Join-Path $repo 'outputs/Alpha6OPS-Setup-0.22.0.exe') -Destination $installer
Copy-Item -LiteralPath (Join-Path $repo 'outputs/Alpha6OPS-Desktop-0.22.0-win-x64.zip') -Destination $zip
$files=@(foreach($f in Get-ChildItem -LiteralPath $publish -Recurse -File){
  $relative=[IO.Path]::GetRelativePath($publish,$f.FullName).Replace('\','/')
  $hash=(Get-FileHash -LiteralPath $f.FullName).Hash
  if((Get-FileHash -LiteralPath (Join-Path $portable $relative)).Hash -ne $hash){throw "Copy mismatch: $relative"}
  [pscustomobject]@{path=$relative;bytes=$f.Length;sha256=$hash}
})
$files|ConvertTo-Json -Depth 4|Set-Content -LiteralPath (Join-Path $target 'payload-manifest.json') -Encoding utf8
$archive=[IO.Compression.ZipFile]::OpenRead($zip)
try{
  $entries=@($archive.Entries|Where-Object{$_.Name})
  if($entries.Count -ne $files.Count){throw 'Portable ZIP file count differs.'}
  $lookup=@{};foreach($f in $files){$lookup[$f.path]=$f.sha256}
  foreach($entry in $entries){
    $stream=$entry.Open()
    try{$hash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($stream))}finally{$stream.Dispose()}
    if($lookup[$entry.FullName.Replace('\','/')] -ne $hash){throw "Portable ZIP mismatch: $($entry.FullName)"}
  }
}finally{$archive.Dispose()}
$setup=[Reflection.Assembly]::LoadFile($installer)
$embedded=$setup.GetManifestResourceStream('payload.zip')
if(!$embedded){throw 'Installer payload absent.'}
try{$embeddedHash=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($embedded))}finally{$embedded.Dispose()}
if($embeddedHash -ne (Get-FileHash -LiteralPath $zip).Hash){throw 'Embedded installer payload differs from verified ZIP.'}
$record=[ordered]@{
 validationBuildId=$id;version='0.22.0';label='7.24C FINAL L1';sourceCommit=(& git -C $repo rev-parse HEAD)
 sourceIsDirty=$true;sourceContentManifestSha256=$sourceHash;sourceSnapshotSha256=(Get-FileHash -LiteralPath (Join-Path $target 'source-snapshot.zip')).Hash
 frozenAtUtc=[DateTimeOffset]::UtcNow.ToString('o');packageDirectory=$target;installerPath=$installer;portableZipPath=$zip
 primaryBinaries=@($files|Where-Object path -in @('Alpha6OPS.exe','Alpha6OPS.dll','Alpha6Ops.Core.dll'))
 packageHashes=@(foreach($p in @($installer,$zip)){[pscustomobject]@{path=$p;sha256=(Get-FileHash -LiteralPath $p).Hash;bytes=(Get-Item -LiteralPath $p).Length}})
 payloadFileCount=$files.Count;portableZipFilesVerified=$files.Count;embeddedPayloadSha256=$embeddedHash
 payloadManifestSha256=(Get-FileHash -LiteralPath (Join-Path $target 'payload-manifest.json')).Hash
 defaultRenderer='classic';mapV2='session opt-in';installed=$false;closure='PASS / CLOSED: read-only logbook correction; disconnected final-package verification passed; native validation belongs to unchanged T2; inherited diagnostic status-write limitation documented'
}
$record|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $target 'validation-build.json') -Encoding utf8
$record|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $run 'frozen-build.json') -Encoding utf8
$record|ConvertTo-Json -Depth 8



