using System.Collections.Concurrent;
using System.Reflection;
using System.Text.Json;
internal static class ExceptionProbe {
 [STAThread] private static int Main(string[] args) {
  var observed = new ConcurrentQueue<object>();
  AppDomain.CurrentDomain.FirstChanceException += (_, e) => { if(e.Exception is System.IO.IOException or UnauthorizedAccessException) observed.Enqueue(new {at=DateTimeOffset.UtcNow, thread=Environment.CurrentManagedThreadId, exception=e.Exception.ToString(), hresult=e.Exception.HResult, stack=Environment.StackTrace}); };
  try { return (int)typeof(Program).GetMethod("Main", BindingFlags.NonPublic | BindingFlags.Static)!.Invoke(null,new object[]{args})!; }
  finally { System.IO.File.WriteAllText(System.IO.Path.Combine(args[1], "first-chance.json"), JsonSerializer.Serialize(observed,new JsonSerializerOptions{WriteIndented=true})); }
 }
}

