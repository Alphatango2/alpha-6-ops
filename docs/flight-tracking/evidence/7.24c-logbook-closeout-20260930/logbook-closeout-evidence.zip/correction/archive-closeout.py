from pathlib import Path
import hashlib, json, shutil, zipfile

repo = Path(__file__).resolve().parents[3]
run = Path(__file__).resolve().parent
baseline = repo / 'work/checkpoint-7.24c/full-20260930-120544-40822fea'
evidence = repo / 'docs/flight-tracking/evidence/7.24c-logbook-closeout-20260930'
report = repo / 'docs/flight-tracking/7.24c-logbook-correction-closeout.md'
load = lambda p: json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest().upper()
def save(p, value):
    Path(p).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

summary = load(run / 'verification-summary.json')
assert summary['closingSet'] == dict(executed=2492, passed=2492, failed=0, skipped=2)
assert summary['historicalSamples'] == 100632 and summary['preservedFinalNativeSamples'] == 6197
preserved = load(run / 'preservation-before.json')
assert all(Path(p['path']).is_file() and sha(p['path']) == p['sha256'] for p in preserved)
freeze = load(run / 'frozen-build.json')
frozen = Path(freeze['packageDirectory'])
for item in freeze['packageHashes']:
    assert sha(item['path']) == item['sha256']
for item in load(frozen / 'payload-manifest.json'):
    assert sha(frozen / 'portable' / item['path']) == item['sha256']
native = load(run / 'final-disconnected-logbook/logbook-checks.json')
assert native['desktopSha256'] == sha(frozen / 'portable/Alpha6OPS.dll')
assert native['passed'] == 40 and native['failed'] == 0 and not native['simulatorConnected']

evidence.mkdir(exist_ok=False)
blocked = {'bin', 'obj', 'final-package-harness', 'frozen-t2-control', '__pycache__'}
allowed = {'.json', '.jsonl', '.txt', '.log', '.stdout', '.stderr', '.png', '.cs', '.csproj', '.ps1', '.py', '.md', '.diff', '.patch'}
items = []
for prefix, directory in [('correction', run), ('full-baseline', baseline)]:
    for p in sorted(directory.rglob('*')):
        relative = p.relative_to(directory)
        if not p.is_file() or blocked.intersection(relative.parts) or p.suffix.lower() not in allowed:
            continue
        items.append((prefix + '/' + relative.as_posix(), p))
items.append(('7.24c-logbook-correction-closeout.md', report))
archive = evidence / 'logbook-closeout-evidence.zip'
manifest = [dict(path=name, sha256=sha(p), bytes=p.stat().st_size) for name, p in items]
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, p in items:
        z.write(p, name)
with zipfile.ZipFile(archive) as z:
    assert len(z.infolist()) == len(manifest)
    for item in manifest:
        assert hashlib.sha256(z.read(item['path'])).hexdigest().upper() == item['sha256']
save(evidence / 'archive-manifest.json', manifest)
for name in ['verification-summary.json', 'preservation-after.json', 'source-delta.json', 'review.md']:
    shutil.copy2(run / name, evidence / name)
for name in ['JST500-disconnected-logbook.png', 'JST500-interrupted-disconnected-logbook.png', 'JST771-disconnected-logbook.png']:
    shutil.copy2(run / 'final-disconnected-logbook' / name, evidence / name)
save(evidence / 'index.json', dict(
    checkpoint='7.24C', status='PASS / CLOSED',
    report=report.relative_to(repo).as_posix(),
    archive=archive.name, archiveSha256=sha(archive), archiveFiles=len(manifest),
    summary=summary, frozenBuild=freeze['validationBuildId'],
    installerSha256=freeze['packageHashes'][0]['sha256'],
    finalDesktopSha256=native['desktopSha256'], preservedFiles=len(preserved),
    preservedChanged=0, noNativeConnection=True, installed=False,
    failureEvidencePreserved=True,
    excluded='Executable/dependency caches and temporary SQLite copies; database source retained in original T2 evidence. All JSON assertions, failures, probes, logs and screenshots included.'))
shutil.copy2(report, frozen / 'CLOSEOUT.md')
shutil.copy2(run / 'verification-summary.json', frozen / 'verification-summary.json')
shutil.copy2(run / 'final-disconnected-logbook/logbook-checks.json', frozen / 'logbook-verification.json')
save(frozen / 'closeout-evidence.json', dict(path=str(evidence), archiveSha256=sha(archive), indexSha256=sha(evidence / 'index.json')))
frozen_manifest = [dict(path=p.relative_to(frozen).as_posix(), sha256=sha(p), bytes=p.stat().st_size)
                   for p in sorted(frozen.rglob('*')) if p.is_file()]
save(frozen / 'final-freeze-manifest.json', frozen_manifest)
save(run / 'archive-result.json', dict(evidence=str(evidence), archiveSha256=sha(archive), archiveFiles=len(manifest),
     frozenFiles=len(frozen_manifest), finalFreezeManifestSha256=sha(frozen / 'final-freeze-manifest.json')))
print(json.dumps(load(run / 'archive-result.json'), indent=2))
