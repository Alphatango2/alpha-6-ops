"""Read preserved T2 native evidence only; write analysis beside it."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import csv
import hashlib
import json
import sqlite3
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def at(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))

def elapsed(a, b):
    return (at(b) - at(a)).total_seconds()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()

def status(row):
    # Derived assessment of the frozen Core TerminalShutdownEvidence.Status predicate,
    # using journal recording time as the receipt-side evaluation time. This is not
    # an IN/PIREP decision, not new telemetry, and not execution of production Core.
    ev = row["detail"]["terminalShutdown"]
    now = row["recordedAtUtc"]
    fresh = lambda value: 0 <= elapsed(value, now) <= 3
    if not ev["Valid"] or ev["SimulatorUtc"] != row["simulatorUtc"] or not ev["ConnectionId"] or not fresh(ev["ReceivedUtc"]):
        return "Invalid"
    if ev["Support"] == 0:
        return "Operating" if ev.get("OperatingEvidence", False) else "Unavailable"
    eng = ev["Engines"]
    count = ev["ExpectedEngineCount"]
    if not ev["Qualified"] or not 1 <= count <= 4 or len(eng) != count or sorted(e["Index"] for e in eng) != list(range(1, count+1)) or any(e["Cutoff"] is None or e["Combustion"] is None or not fresh(e["ReceivedUtc"]) for e in eng):
        return "Invalid"
    if any(e["Cutoff"] and e["Combustion"] for e in eng):
        return "Invalid"
    return "Operating" if ev.get("OperatingEvidence", False) or any(e["Cutoff"] is not True or e["Combustion"] is not False for e in eng) else "Confirmed"

def point(row):
    return dict(sequence=row["sequence"], recordedUtc=row["recordedAtUtc"], simulatorUtc=row["simulatorUtc"],
                derivedShutdownStatus=status(row), terminalShutdown=row["detail"]["terminalShutdown"],
                engineDataValid=row["detail"]["engineDataValid"], engineReadings=row["detail"]["engineReadings"],
                engineStates=row["detail"]["engineStates"])

sessions = []
all_samples = []
all_rows = []
for journal in sorted((HERE / "logs").glob("*.jsonl")):
    rows = [json.loads(line) for line in journal.read_text().splitlines()]
    export = load(journal.with_suffix(".json"))
    samples = [r for r in rows if r["kind"] == "telemetry"]
    tracking = [r for r in rows if r["kind"] == "tracking_state"]
    opened = next(r for r in rows if r["kind"] == "connection_opened")
    qualified = next(r for r in samples if r["detail"]["terminalShutdown"]["Qualified"])
    all_samples.extend(samples)
    all_rows.extend(rows)
    sessions.append(dict(
        journal=journal.name, events=len(rows), samples=len(samples),
        contiguousSequence=[r["sequence"] for r in rows] == list(range(1, len(rows)+1)),
        exportMatchesJournal=export["events"] == rows and export["eventCount"] == len(rows),
        closedComplete=export["sessionEnded"] and not export["incompleteLastLine"],
        suppliedMatchesOriginal=digest(HERE/"supplied"/journal.name)==digest(journal) and digest(HERE/"supplied"/journal.with_suffix(".json").name)==digest(journal.with_suffix(".json")),
        openedUtc=opened["recordedAtUtc"], endedUtc=rows[-1]["recordedAtUtc"], endReason=rows[-1]["detail"]["reason"],
        connectionIds=sorted({r["detail"]["terminalShutdown"]["ConnectionId"] for r in samples}),
        connectionGenerations=sorted({r["detail"]["connectionGeneration"] for r in rows if r["kind"]=="terminal_block_in"}),
        aircraft=sorted({r["detail"]["aircraft"] for r in samples}),
        providers=sorted({r["detail"]["terminalShutdown"]["Provider"] for r in samples}),
        expectedEngineCounts=sorted({r["detail"]["terminalShutdown"]["ExpectedEngineCount"] for r in samples}),
        supportCounts=dict(Counter(r["detail"]["terminalShutdown"]["Support"] for r in samples)),
        qualificationCounts=dict(Counter(r["detail"]["terminalShutdown"]["Qualified"] for r in samples)),
        firstQualification=point(qualified), secondsFromOpenToQualified=elapsed(opened["recordedAtUtc"],qualified["recordedAtUtc"]),
        firstQualifiedInputsFreshInConnection=all(at(e["ReceivedUtc"]) >= at(opened["recordedAtUtc"]) for e in qualified["detail"]["terminalShutdown"]["Engines"]),
        firstQualifiedBothRunning=all(e["Cutoff"] is False and e["Combustion"] is True for e in qualified["detail"]["terminalShutdown"]["Engines"]),
        derivedStatusCounts=dict(Counter(status(r) for r in samples)),
        phases=dict(Counter(r["detail"]["phase"] for r in tracking)),
        noTerminalEligibility=all(not r["detail"]["TerminalBlockInEligible"] and not r["detail"]["PilotConfirmedBlockIn"] for r in tracking),
        policyEvents=[r for r in rows if r["kind"] == "terminal_block_in"],
        trackingEvents=[r for r in rows if r["kind"] == "tracking_event"],
        sampleGapSeconds=[elapsed(a["recordedAtUtc"],b["recordedAtUtc"]) for a,b in zip(samples,samples[1:])],
    ))

final = [r for r in all_samples if r["detail"]["terminalShutdown"]["ConnectionId"] == sessions[-1]["connectionIds"][0]]
cutoffs = [next(r for r in final if r["detail"]["terminalShutdown"]["Engines"][i]["Cutoff"] is True) for i in range(2)]
off = [next(r for r in final if r["detail"]["terminalShutdown"]["Engines"][i]["Combustion"] is False) for i in range(2)]
confirmed = next(r for r in final if status(r)=="Confirmed")
single = [r for r in final if r["detail"]["terminalShutdown"]["Engines"][0]["Cutoff"] is True and r["detail"]["terminalShutdown"]["Engines"][1]["Cutoff"] is False]
semantic = dict(engineCutoffs=[point(r) for r in cutoffs], combustionOff=[point(r) for r in off],
    firstConfirmed=point(confirmed),
    cutoffToCombustionOffSeconds=[elapsed(a["recordedAtUtc"],b["recordedAtUtc"]) for a,b in zip(cutoffs,off)],
    observedCutoffSeparationSeconds=elapsed(cutoffs[0]["recordedAtUtc"],cutoffs[1]["recordedAtUtc"]),
    secondCutoffToConfirmedSeconds=elapsed(cutoffs[1]["recordedAtUtc"],confirmed["recordedAtUtc"]),
    secondCutoffToDisconnectSeconds=elapsed(cutoffs[1]["recordedAtUtc"],sessions[-1]["endedUtc"]),
    lastSampleAfterSecondCutoffSeconds=elapsed(cutoffs[1]["recordedAtUtc"],final[-1]["recordedAtUtc"]),
    connectedBeforeFirstCutoffSeconds=elapsed(sessions[-1]["openedUtc"],cutoffs[0]["recordedAtUtc"]),
    singleEngineOffSamples=len(single), singleEngineOffStatuses=dict(Counter(status(r) for r in single)),
    allConfirmedStayConfirmed=all(status(r)=="Confirmed" for r in final if r["sequence"]>=confirmed["sequence"]),
    genericEngineDataValidity=dict(Counter(r["detail"]["engineDataValid"] for r in all_samples)))

prior = ROOT / "work/checkpoint-7.24c/jst771-review-20260929/recovery-review/supplemental/Alpha6OPS-flights.sqlite"
snap = HERE / "sqlite-backups/Alpha6OPS-flights.sqlite"
def db_rows(path):
    with sqlite3.connect(path.as_uri()+"?mode=ro&immutable=1",uri=True) as db:
        db.row_factory = sqlite3.Row
        return {table: [dict(r) for r in db.execute(f"SELECT * FROM {table} ORDER BY {order}")] for table,order in [("flight","id"),("flight_event","flight_id,sequence")]}
old,new=db_rows(prior),db_rows(snap)
identity="4208cd32c171441c891cb4429b5f19d8"
history=dict(priorSnapshot=str(prior), currentSnapshot=str(snap),
    unchangedTables={t:old[t]==new[t] for t in old}, tableCounts={t:len(new[t]) for t in new},
    jst771Rows=[r for r in new["flight"] if r["flight_number"]=="JST771"],
    jst771EventCount=sum(r["flight_id"]==identity for r in new["flight_event"]),
    jst771Pireps=[r for r in new["flight_event"] if r["flight_id"]==identity and r["kind"]=="pirep_submitted"],
    rawProfileHistoryHashMatchesOld=digest(HERE/"profile/Alpha6OPS-flights.sqlite")==digest(prior))
frozen=ROOT/"outputs/Alpha6OPS-Desktop-S4-7.24C-T2-20260929-f421af15530c"
source_match={}
with zipfile.ZipFile(frozen/"source-snapshot.zip") as z:
    for name in ["src/Alpha6Ops.Core/TerminalShutdown.cs","src/Alpha6Ops.Desktop/ShutdownIntentAdapters.cs","src/Alpha6Ops.Desktop/FlightSessionCoordinator.TerminalShutdown.cs"]:
        source_match[name]=z.read(name)==(ROOT/name).read_bytes()

result=dict(evidenceDirectory=str(HERE), eventCount=len(all_rows), telemetrySamples=len(all_samples),
    sessionCount=len(sessions), sessions=sessions, semanticShutdown=semantic, history=history,
    frozenSourceMatchesReadCode=source_match,
    allGroundBrakedUnpaused=all(r["detail"]["onGround"] and r["detail"]["parkingBrake"] and not r["detail"]["paused"] and not r["detail"]["slewing"] for r in all_samples),
    maxGroundSpeedKnots=max(r["detail"]["groundSpeedKnots"] for r in all_samples),
    maxFreshQualifiedEngineAgeSeconds=max(elapsed(e["ReceivedUtc"],r["recordedAtUtc"]) for r in all_samples if r["detail"]["terminalShutdown"]["Qualified"] for e in r["detail"]["terminalShutdown"]["Engines"]),
    allPolicyGuardsWithoutOn=all(not r["detail"]["HasOn"] and not r["detail"]["AtDestination"] and not r["detail"]["SessionValid"] and not r["detail"]["decision"]["TerminalEligible"] and not r["detail"]["decision"]["CanConfirm"] for r in all_rows if r["kind"]=="terminal_block_in"),
    eventKindCounts=dict(Counter(r["kind"] for r in all_rows)),
    reconnectGapSeconds=elapsed(sessions[0]["endedUtc"],sessions[1]["openedUtc"]),
    restartGapSeconds=elapsed(sessions[1]["endedUtc"],sessions[2]["openedUtc"]))
(HERE/"analysis.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
with (HERE/"terminal-timeline.csv").open("w",encoding="utf-8",newline="") as f:
    w=csv.writer(f); w.writerow(["connection","sequence","recordedUtc","simulatorUtc","qualified","derivedStatus","engine1Cutoff","engine1Combustion","engine2Cutoff","engine2Combustion","engine1N1","engine1N2","engine2N1","engine2N2","genericEngineValid"])
    for r in all_samples:
        d=r["detail"]; e=d["terminalShutdown"]; engines=e["Engines"]; physical={p["Index"]:p for p in d["engineReadings"]}
        rpm=lambda engine,key: physical.get(engine,{}).get(key)
        w.writerow([e["ConnectionId"],r["sequence"],r["recordedAtUtc"],r["simulatorUtc"],e["Qualified"],status(r),engines[0]["Cutoff"],engines[0]["Combustion"],engines[1]["Cutoff"],engines[1]["Combustion"],rpm(1,"N1Percent"),rpm(1,"N2Percent"),rpm(2,"N1Percent"),rpm(2,"N2Percent"),d["engineDataValid"]])
print(json.dumps({k:v for k,v in result.items() if k not in ["sessions","history","semanticShutdown"]},indent=2))
print("SESSIONS",json.dumps([{k:v for k,v in s.items() if k not in ["firstQualification","policyEvents","trackingEvents","sampleGapSeconds"]} for s in sessions],indent=2))
print("SHUTDOWN",json.dumps({k:v for k,v in semantic.items() if k not in ["engineCutoffs","combustionOff","firstConfirmed"]},indent=2))
print("HISTORY",json.dumps({k:v for k,v in history.items() if k not in ["jst771Rows","jst771Pireps"]},indent=2))
