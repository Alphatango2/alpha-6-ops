"""Verify read-only review preservation; archive evidence without changing T2."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
DEST=ROOT/'docs/flight-tracking/evidence/7.24c-t2-final-20260930'
REPORT=ROOT/'docs/flight-tracking/7.24c-final-t2-destination-validation.md'
PROFILE=Path('C:/Users/DanniBaLs/AppData/Local/Alpha6Designs/Alpha6OPS')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def save(p,v):p.write_text(json.dumps(v,indent=2),encoding='utf-8')

before=load(HERE/'source-hashes-before.json')
source_checks=[{'path':r['path'],'expected':r['sha256'],'actual':sha(ROOT/r['path'])} for r in before]
for r in source_checks:r['match']=r['expected']==r['actual']
preservation=[]
for r in load(HERE/'preservation-manifest.json'):
    preservation.append({'source':r['source'],'copy':r['copy'],'expected':r['sha256'],
                         'sourceMatch':sha(Path(r['source']))==r['sha256'],'copyMatch':sha(Path(r['copy']))==r['sha256']})
frozen=load(HERE/'gate-review/frozen-integrity.json')
packages=[]
for r in frozen['packageChecks']:
    packages.append({'path':r['path'],'expected':r['expected'],'actual':sha(Path(r['path']))})
for r in packages:r['match']=r['actual']==r['expected']
crash_inventory=[{'path':str(p),'modifiedUtc':datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat(),'sha256':sha(p)}
                 for p in sorted((PROFILE/'CrashReports').glob('*')) if p.is_file()]
new_crashes=[r for r in crash_inventory if r['modifiedUtc']>='2026-09-30T14:36:15']
save(HERE/'pilot-clarification.json',{
    'source':'Direct user response during final review, 2026-09-30',
    'answer':'No video was taken as the screen record program potentially crashed my sim for the first Jetstar Flight that was interrupted.',
    'interpretation':'No terminal video exists; physical switch and first-visible-button timing are unmeasured. Recording software as the cause of the earlier external failure remains a pilot hypothesis.'})
analysis=load(HERE/'flight-analysis.json')
identity=load(HERE/'persistence-review/identity-analysis.json')
result={
    'reviewedUtc':datetime.now(timezone.utc).isoformat(),
    'nativeTerminalGate':'PASS','checkpointClosure':'NO-GO: logbook OFF presentation defect requires disposition',
    'sourceFileCount':len(source_checks),'sourceChecks':source_checks,
    'preservedFileCount':len(preservation),'preservationChecks':preservation,
    'packageChecks':packages,'crashInventory':crash_inventory,'newCrashReports':new_crashes,
    'flightEvidenceChecks':analysis['checks'],'nativeSamples':analysis['telemetrySamples'],
    'databaseByteIdentical':identity['database_byte_identical'],
    'historicalTestsRerun':False,'productionChanges':False,
}
save(HERE/'review-verification.json',result)
assert all(r['match'] for r in source_checks),'Existing production/test/build source changed during review'
assert all(r['sourceMatch'] and r['copyMatch'] for r in preservation),'Source/evidence preservation mismatch'
assert all(r['match'] for r in packages),'Frozen package mismatch'
assert all(analysis['checks'].values()),'Flight evidence check failed'
assert not new_crashes,'Review new crash evidence'
assert identity['database_byte_identical'] and identity['database_all_rows_identical']

DEST.mkdir(parents=True,exist_ok=True)
archive=DEST/'final-t2-review-evidence.zip'
assert not archive.exists(),'Never overwrite an existing frozen review archive'
included=[
    'original/S4 - FINAL T2 DESTINATION VALIDATION.zip','original/closure-guidelines.txt',
    'preservation-manifest.json','zip-entry-manifest.json','profile-inventory.json',
    'source-hashes-before.json','pilot-clarification.json','review-verification.json',
    'flight-analysis.json','terminal-telemetry.csv','analyze-flight.py','verify-and-archive-review.py',
    'supplemental/profile/Alpha6OPS-flights.sqlite','supplemental/profile/Alpha6OPS-logs.sqlite',
    'supplemental/profile/program-status.json',
    'persistence-review/PERSISTENCE-IDENTITY-REVIEW.md','persistence-review/identity-analysis.json',
    'persistence-review/inspect_persistence.py','persistence-review/analyze_identity.py',
    'persistence-review/frozen-PilotLogbookWorkspace.xaml.cs.txt','persistence-review/frozen-FlightHistoryDatabase.cs.txt',
    'gate-review/gate-chain-review.md','gate-review/frozen-integrity.json',
    'gate-review/prior-failure-preservation.json','gate-review/source-continuity.json',
]
manifest=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for rel in included:
        p=HERE/rel;z.write(p,rel);manifest.append({'entry':rel,'sha256':sha(p),'bytes':p.stat().st_size})
    z.write(REPORT,'7.24c-final-t2-destination-validation.md')
    manifest.append({'entry':'7.24c-final-t2-destination-validation.md','sha256':sha(REPORT),'bytes':REPORT.stat().st_size})
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for r in manifest:assert hashlib.sha256(z.read(r['entry'])).hexdigest().upper()==r['sha256']
save(DEST/'archive-manifest.json',{'archive':archive.name,'sha256':sha(archive),'entries':manifest,
                                'status':'Native terminal PASS; checkpoint closure NO-GO pending logbook OFF-display disposition'})
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True)
(HERE/'git-status-after.txt').write_text(status,encoding='utf-8')
old=set((HERE/'git-status-before.txt').read_text(encoding='utf-8-sig').splitlines())
delta={'added':sorted(set(status.splitlines())-old),'removed':sorted(old-set(status.splitlines()))}
save(HERE/'git-status-review-delta.json',delta)
print(json.dumps({'sourceFilesUnchanged':len(source_checks),'preservedSourceAndCopyPairs':len(preservation),
                  'packageChecks':len(packages),'nativeEvidencePassed':sum(analysis['checks'].values()),
                  'nativeEvidenceFailed':sum(not v for v in analysis['checks'].values()),
                  'newCrashReports':len(new_crashes),'archiveEntries':len(manifest),
                  'archive':str(archive),'archiveSha256':sha(archive),'gitStatusDelta':delta},indent=2))
