from pathlib import Path
import sqlite3, shutil, json, hashlib

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
SOURCES={
 'supplied_pre_restart':ROOT/'extracted'/'S4 - FINAL T2 DESTINATION VALIDATION'/'01-after-submit-before-restart',
 'supplemental_current_closed':ROOT/'supplemental'/'profile',
}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

result={}
for label,src in SOURCES.items():
 result[label]={}
 for db in ('Alpha6OPS-flights.sqlite','Alpha6OPS-logs.sqlite'):
  dest=OUT/'db-copies'/label/db
  dest.parent.mkdir(parents=True,exist_ok=True)
  assert not Path(str(src/db)+'-wal').exists(), 'Need full valid WAL-aware clone'
  shutil.copy2(src/db,dest)
  assert sha(src/db)==sha(dest)
  con=sqlite3.connect(dest.as_uri()+'?mode=ro&immutable=1',uri=True)
  con.row_factory=sqlite3.Row
  schemas=[dict(r) for r in con.execute("SELECT name,sql FROM sqlite_master WHERE type='table'")]
  tables={r['name']:[dict(x) for x in con.execute('SELECT * FROM "'+r['name']+'"')] for r in schemas}
  data={'sha256':sha(dest),'integrity_check':con.execute('PRAGMA integrity_check').fetchall()[0][0], 'schemas':schemas,'tables':tables}
  result[label][db]=data
  con.close()
  print(label,db,data['sha256'],data['integrity_check'])
  for schema in schemas:
   print(schema['name'],len(tables[schema['name']]),schema['sql'])
(OUT/'database-dump.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
