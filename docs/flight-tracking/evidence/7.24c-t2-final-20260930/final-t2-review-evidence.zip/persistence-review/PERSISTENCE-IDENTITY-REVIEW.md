# Frozen T2 final JST500 — persistence and identity evidence review

Reviewed read-only on 2026-09-30. No production edits, builds, installs, live database opens, simulator actions, sidecar merges, or repeat flights. All analysis outputs and disposable database copies are confined to this directory.

## Finding and disposition

**Durable cold-start persistence, same-flight-number session isolation, successful PIREP uniqueness and no assignment resurrection: PASS using the supplied evidence plus the separately labeled supplemental current closed-app profile.** The ZIP alone does not prove post-restart database uniqueness or unchanged database contents because both post-restart main SQLite files are missing.

**Correct logbook OFF display: FAIL.** The completed JST500 logbook summary displays takeoff-roll time `20:07:15Z`, although authoritative liftoff/PIREP OFF is `20:07:33.8616943Z`. This is a preexisting presentation-selection defect also present in frozen T1 and the JST771 event data. It is not a lost/changed durable milestone and does not negate the successful T2 automatic-terminal gate, but an unqualified claim that every displayed OOOI value is correct would be false. A strict closure requirement for correct actual OOOI display remains unsatisfied until fixed or explicitly dispositioned. No production correction was made during this review.

## Preservation and method

Sources are under the enclosing evidence root:

- Supplied pre-restart: `extracted/S4 - FINAL T2 DESTINATION VALIDATION/01-after-submit-before-restart`.
- Supplied post-restart: `extracted/S4 - FINAL T2 DESTINATION VALIDATION/02-after-restart`.
- Supplemental current closed-app profile: `supplemental/profile`, copied at evidence preservation time `2026-09-30T16:36:24.359000Z`, with stable source/copy hashes in `preservation-manifest.json` and active-file inventory in `profile-inventory.json`.

`inspect_persistence.py` copied each complete pre-restart and supplemental database into `db-copies`, checked source/copy SHA-256 equality, and queried those copies with SQLite `mode=ro&immutable=1`. Neither complete source folder contains a WAL, so immutable reads do not discard required uncheckpointed data. Both flight databases and both diagnostic-index databases return `PRAGMA integrity_check = ok`. The unpaired supplied post-restart WAL/SHM files were never attached to a guessed main database.

The supplied post-restart folder has a zero-byte flight WAL, a 32,768-byte flight SHM, a 4,120,032-byte diagnostic-index WAL, and a 32,768-byte diagnostic-index SHM. These are not substitutes for either missing main database. Its live status and screenshot prove a disconnected reopened instance and empty active UI, not database uniqueness by themselves.

The pre-restart and supplemental current flight databases are byte-for-byte identical:

`1EAC6BDBE318E21EAB73E4187FCF03D8B0AFE021224CEBE03DBB1BDB4F484278`

Each contains exactly 502 `flight` rows and 1,157 `flight_event` rows. All logical rows also compare equal. The database file's preserved source mtime is `2026-09-30T16:22:16.528993Z`; its lack of modification during the subsequent disconnected restart is consistent with this equality.

The diagnostic-index database has 217 entries in both snapshots, the same path set and all the same fields except `indexed_utc` in 213 rows. This is index refresh activity, not flight history mutation. Its pre-restart hash is `57C270ACBDB93DEB1811A00171168A10A2EAC176A7F941010FF9659D3E40D15C`; supplemental hash is `6FA742D4F8ECC6B5534DC70ABBEA210F4E58085FEABC40ABBE1EBBA52E049E53`.

## Successful operational session

- Flight: JST500, YMML → YSSY, aircraft history label Airbus A320.
- Journal session identity: `ce0d6dfa6bcb4156b016f9a41a8c2d95`.
- Durable history identity: `e475984bc9f54f8ab466e75a0d443759`.
- One `flight_assignment` at computer UTC `2026-09-30T14:36:15.1918952Z`, planned departure `2026-09-29T20:00:00Z`, planned arrival `21:35:00Z`, departure gate 45, arrival gate 56, route `YMML/34 DOSEL2 DOSEL Y59 RIVET RIVET5 YSSY/34L`.
- Journal starts `2026-09-30T14:36:15.1890544Z`; connection opens `14:36:15.2918504Z`; monitoring armed `14:36:15.8915812Z` / simulator `2026-09-29T19:44:39.8362731Z`, `joinedInProgress=false`.
- Native aircraft is `FenixA320 IAE WF`; observed registration `VH-VGF`, accepted plan registration `G-FENX`. The existing explicit advisory reports the registration difference and accepts the assigned flight with the observed aircraft. This is not a session-identity collision.
- History row begins at computer `2026-09-30T14:49:13.9560246Z`, when OUT causes history materialization; this is not the earlier journal start time. History row ends at computer `16:16:50.2334174Z` and final phase is `Complete`.

Durable PIREP actuals, all simulator UTC on 2026-09-29:

| Milestone | Authoritative simulator UTC | Journal milestone sequence | History tracking sequence |
|---|---|---:|---:|
| OUT | 19:57:34.8304672Z | 1569 | 6 |
| OFF | 20:07:33.8616943Z | 2779 | 14, Liftoff |
| ON | 21:16:56.8319549Z | 11123 | 31, Touchdown |
| IN | 21:25:10.8307495Z | 12125 | 42, Block-in / flight complete |

Exactly one journal milestone exists for each of TaxiOut, Airborne, TaxiIn and Complete. All 42 journal tracking events match the 42 durable tracking rows by full parsed content and simulator instant; the stored timezone offsets normalize to the same instants. Database sequences 1–43 are contiguous, with no repeated sequence and one final PIREP event.

The final tracking event has effective IN `21:25:10.8307495Z`, while the preceding sequence-41 Engine 2 shutdown event uses `21:25:12.831108Z`. This simulator-time reversal reflects the lifecycle's backdated effective IN at the start of a successful stable interval, not duplicate IN or sequence corruption. Recorded computer timestamps remain ordered. Lifecycle-publication latency belongs to the companion terminal review; it must not be inferred by subtracting unrelated simulator and computer clocks.

## PIREP and closeout ownership

The database schema stores PIREPs as `flight_event.kind='pirep_submitted'`, not as rows in a separate PIREP table. Exactly one such row exists for successful history ID `e475984bc9f54f8ab466e75a0d443759`, at sequence 43:

- PIREP payload `submittedUtc`: `2026-09-30T16:19:32.3053592Z`.
- Database event recorded UTC: `2026-09-30T16:19:32.306684Z`.
- Status `Completed`; `pilotConfirmedBlockIn=false`; `eventCount=42`; route and four actuals above.
- Journal sequence 12453: one `pirep_closeout_complete`, computer UTC `16:19:32.3135746Z`, `FlightNumber=JST500`.
- Journal sequence 12454: `session_ended`, computer UTC `16:19:32.3143744Z`, reason `pirep_submitted`.

Only `session_ended` follows closeout in the complete export. The durable session has no event after PIREP sequence 43; all flight database bytes remain unchanged through the preserved restart. These jointly support no recorded lifecycle mutation after closeout, no duplicate PIREP, and no duplicate completed history row. The earlier interrupted history has zero PIREP events.

## Cold restart and empty active state

| Evidence | Computer UTC / identity | Result |
|---|---|---|
| Supplied pre-restart stopped status | `16:22:16.5178334Z`, PID 28428 | `running=false`, `application_exit`, Disconnected |
| Supplied restart live status | `processStartUtc=16:25:38.5343964Z`, PID 13572 | New process, Disconnected, aircraft null, samples 0, simulator UTC null |
| Live restart heartbeat | `16:27:09.202573Z` | New process alive 90.6681766 seconds after start, `lastCrashReport=null` |
| Supplemental final stopped status | `16:27:43.9580348Z`, PID 13572 | Same restarted process exited normally, Disconnected, aircraft null, samples 0 |
| Supplemental profile inventory | `16:36:24.359000Z` | `active-flight.json` absent; `active-flight-state.json` absent |

Visual inspection using `view_image`:

- `S4FFT 8.JPG`: connected at 16:17Z, JST500 YMML → YSSY, BLOCK-IN / COMPLETE, actual OUT/IN shown, enabled SUBMIT PIREP. This is a pre-submission eligibility screenshot, not an exact first-appearance measurement.
- `S4FFT 9.JPG`: completed JST500 and a distinct interrupted JST500 in the logbook, 502 total histories; selected completed record includes an event timeline and OUT/ON/IN, with the OFF-summary defect described below. The screenshot's location and visible content alone do not independently timestamp it as post-restart.
- `02-after-restart/S4FFT 10.JPG`: disconnected at 16:26Z, Operations says no active flight, no active assignment, assigned (0), no flights in view, no assigned airports, empty current activity. No repeat submission prompt is visible on that screen.

Pilot notes report no repeat prompt and preserved details after restart. The screenshot, missing active files, new zero-sample process, normal final stop and identical durable database support the reported outcome. The snapshot does not capture every instant or every possible screen; no broader claim is needed.

## Earlier interrupted JST500 and identity isolation

- Durable history identity: `0bbf3ce8af1d4880ad8d9ed5f0ce4fbe`.
- Journal identity recorded in `source_detail`: `daf629044b6643089d70bcdb0b2c9d6f`, filename beginning `Alpha6OPS-20260930-132444-...`.
- History begins computer UTC `2026-09-30T13:53:13.7294959Z`, ends `14:13:45.9504026Z`, final phase `Interrupted`.
- Sixteen tracking rows, contiguous sequences 1–16; zero PIREP rows.
- OUT: simulator `2026-09-29T20:00:32.6470108Z`, history sequence 6 (`Block-out / taxi out`).
- No Takeoff roll, Liftoff, Touchdown, Block-in, or completed event: no durable OFF, ON or IN was fabricated.
- Last retained event: `Flaps 1+F selected`, simulator `20:20:02.1882705Z`, computer `14:12:41.130479Z`; engine-shutdown events immediately precede it, still with no completion.
- This record's identity, interrupted final state, sixteen events and lack of PIREP survive byte-identically alongside the later completed record.

Both operations reuse flight number and route, but have distinct history IDs, distinct journal IDs, separate event ownership and separate final phases. The successful journal source links directly to the successful row; its one PIREP foreign key belongs to that row. The export/schema does not expose a separate arbitrary assignment GUID, so none is invented here. Distinct operational assignment lifetimes are established by the independent source/history identities and assignment-loaded timelines.

The earlier raw journal/export is indexed in the diagnostic database but is not included in the frozen supplied/supplemental file set reviewed here. Therefore the earlier attempt's full telemetry and the external Fenix malfunction are not independently reconstructed. The pilot's Fenix/tray/black-display explanation is preserved as incident context; the retained S4 abort outcome is consistent with a pre-takeoff interrupted session and reveals no fabricated completion or PIREP. No evidence here makes that external malfunction a T2 fault.

## Logbook OFF presentation defect

`PilotLogbookWorkspace.xaml.cs:79–80` computes each displayed actual from the first event whose title contains any supplied search string. OFF calls `At("Liftoff","Takeoff")`; the event list is ordered by database sequence (`FlightHistoryDatabase.cs:169`). A prior `Takeoff roll` therefore wins before `Liftoff`. The search-term order does not make Liftoff a preferred fallback. The view also does not use the authoritative stored PIREP actuals for this summary.

For successful JST500:

- Sequence 13, Takeoff roll: `2026-09-29T20:07:15.8467025Z`.
- Sequence 14, Liftoff and durable PIREP actualOff: `2026-09-29T20:07:33.8616943Z`.
- Error: summary displays `20:07:15Z`, 18.0149918 seconds early in the underlying selected timestamp.
- S4FFT 9 visibly corroborates this exact display. OUT/ON/IN select the correct corresponding event in this flight. Its full event timeline retains the correct Liftoff; PIREP is correct.

For prior JST771 history `4208cd32c171441c891cb4429b5f19d8`:

- Sequence 13, Takeoff roll: `2026-09-28T21:51:34.3049011Z`.
- Sequence 14, Liftoff and durable PIREP actualOff: `2026-09-28T21:52:01.3083724Z`.
- Same selector would display 21:51:34Z, 27.0034713 seconds early; OUT/ON/IN match its PIREP. This is a code/data projection, not a claim that an inspected old screenshot visibly showed the error.

The workspace file matches the frozen T2 source archive byte-for-byte. Frozen T1 has the same file hash: `AF04D56F11EB7E41FA8E22F15D4E84251131E17E7D3AE4E1FE4F50830229CA18`. The defect therefore predates T2 and does not show a regression caused by terminal-adapter changes.

Minimum future validation if correct displayed OOOI is a blocking closure requirement: correct this presentation mapping in separately authorized work, then use preserved completed JST500/JST771 records for a focused automated projection check and disconnected logbook smoke check. No additional native flight is needed to establish or exercise this defect. The frozen T2 successful-terminal and durable-history findings remain preserved.

## Reproducible results

- `database-dump.json`: all four read-only database dumps, schemas, hashes and integrity results.
- `identity-analysis.json`: selected history records with exact raw timestamp strings, event ownership, journal/database tracking comparison, first-match UI projection and frozen-source hashes. Normalized UTC strings and timestamp comparison retain the original seventh fractional digit (100 ns).
- `inspect_persistence.py`, `analyze_identity.py`: read-only-copy analysis.
- `frozen-PilotLogbookWorkspace.xaml.cs.txt`, `frozen-FlightHistoryDatabase.cs.txt`: inspected T2 archived source copies.

No additional native flight is justified by these persistence findings. The narrow OFF presentation defect requires explicit disposition when making the final checkpoint-wide closure decision.
