from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import json, hashlib, zipfile, re

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
REPO=ROOT.parents[2]
db=json.loads((OUT/'database-dump.json').read_text(encoding='utf-8'))
pre=db['supplied_pre_restart']['Alpha6OPS-flights.sqlite']
post=db['supplemental_current_closed']['Alpha6OPS-flights.sqlite']
package=ROOT/'extracted'/'S4 - FINAL T2 DESTINATION VALIDATION'
journal=json.loads((package/'01-after-submit-before-restart'/'Alpha6OPS-20260930-143615-ce0d6dfa6bcb4156b016f9a41a8c2d95.json').read_text(encoding='utf-8-sig'))

def dt(v): return datetime.fromisoformat(v).astimezone(timezone.utc) if v else None
def utc(v):
 if not v: return None
 m=re.fullmatch(r'(.+T\d\d:\d\d:\d\d)(?:\.(\d+))?(Z|[+-]\d\d:\d\d)',v)
 base=datetime.fromisoformat(m[1]+m[3]).astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S')
 return base+('.'+m[2] if m[2] else '')+'Z'
def ticks(v):
 if not v: return None
 canonical=utc(v)
 base,frac=(canonical[:-1].split('.')+[''])[:2] if '.' in canonical else (canonical[:-1],'')
 return int(datetime.fromisoformat(base+'+00:00').timestamp())*10000000+int(frac.ljust(7,'0'))
def event_view(e):
 d=json.loads(e['detail_json'])
 return {**e,'detail':d,'recorded_utc_normalized':utc(e['recorded_utc']),'simulator_utc_normalized':utc(e['simulator_utc'])}

result={'database_byte_identical':pre['sha256']==post['sha256'],'database_all_rows_identical':pre['tables']==post['tables'],'flights':{},'frozen_source':{}}
for f in pre['tables']['flight']:
 if f['flight_number'] not in ('JST500','JST771'): continue
 events=[event_view(e) for e in pre['tables']['flight_event'] if e['flight_id']==f['id']]
 result['flights'][f['id']]={'row':f,'started_utc_normalized':utc(f['started_utc']),'ended_utc_normalized':utc(f['ended_utc']),'events':events,'count_by_kind':dict(Counter(e['kind'] for e in events)), 'contiguous_sequence': [e['sequence'] for e in events]==list(range(1,len(events)+1))}
 operational={}
 for label,terms in [('OUT',['Block-out']),('OFF',['Liftoff','Takeoff']),('ON',['Touchdown']),('IN',['Block-in','completed'])]:
  match=next((e for e in events if any(term.lower() in e['detail'].get('Title','').lower() for term in terms)),None)
  operational[label]={'sequence':match['sequence'],'title':match['detail']['Title'],'simulatorUtc':utc(match['simulator_utc'])} if match else None
 result['flights'][f['id']]['logbook_first_match_projection']=operational
 if f['id']=='e475984bc9f54f8ab466e75a0d443759':
  stored_tracking=[e for e in events if e['kind']=='tracking_event']
  journal_tracking=[e for e in journal['events'] if e['kind']=='tracking_event']
  matches=[]
  for stored,logged in zip(stored_tracking,journal_tracking):
   matches.append({'sequence':stored['sequence'],'detail_equal':stored['detail']==logged['detail'],'simulator_equal':ticks(stored['simulator_utc'])==ticks(logged['simulatorUtc']),'journal_sequence':logged['sequence']})
  result['tracking_comparison']={'database_count':len(stored_tracking),'journal_count':len(journal_tracking),'all_details_equal':all(m['detail_equal'] for m in matches),'all_simulator_instants_equal':all(m['simulator_equal'] for m in matches),'matches':matches}
result['journal_identity_and_closeout']=[e for e in journal['events'] if e['kind'] in ('session_started','flight_assignment','connection_opened','flight_identification','monitor_armed','flight_milestone','pirep_closeout_complete','session_ended')]
result['journal_after_closeout']=[e for e in journal['events'] if e['sequence']>next(e['sequence'] for e in journal['events'] if e['kind']=='pirep_closeout_complete')]
for name in ('PilotLogbookWorkspace.xaml.cs','FlightHistoryDatabase.cs'):
 relative='src/Alpha6Ops.Desktop/'+name
 live=(REPO/relative).read_bytes()
 frozen_zip=REPO/'outputs'/'Alpha6OPS-Desktop-S4-7.24C-T2-20260929-f421af15530c'/'source-snapshot.zip'
 with zipfile.ZipFile(frozen_zip) as z:
  member=next(n for n in z.namelist() if n.replace('\\','/').endswith(relative))
  frozen=z.read(member)
 result['frozen_source'][relative]={'equal':live==frozen,'sha256':hashlib.sha256(frozen).hexdigest(),'archive':str(frozen_zip),'member':member}
 (OUT/('frozen-'+name+'.txt')).write_bytes(frozen)
with zipfile.ZipFile(REPO/'outputs'/'Alpha6OPS-Desktop-S4-7.24C-T1-20260928-00e3f628b90e'/'source-snapshot.zip') as z:
 t1=z.read('src/Alpha6Ops.Desktop/PilotLogbookWorkspace.xaml.cs')
 result['frozen_t1_logbook_source_sha256']=hashlib.sha256(t1).hexdigest()
before={r['path']:r for r in db['supplied_pre_restart']['Alpha6OPS-logs.sqlite']['tables']['diagnostic_file']}
after={r['path']:r for r in db['supplemental_current_closed']['Alpha6OPS-logs.sqlite']['tables']['diagnostic_file']}
result['diagnostic_index_comparison']={'same_path_set':before.keys()==after.keys(),'changed_field_counts':dict(Counter(k for p in before.keys()&after.keys() for k in before[p] if before[p][k]!=after[p][k]))}
(OUT/'identity-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('DATABASE IDENTICAL',result['database_byte_identical'],result['database_all_rows_identical'])
for fid,f in result['flights'].items():
 print(fid,f['row']['flight_number'],f['row']['final_phase'],f['count_by_kind'],'contiguous',f['contiguous_sequence'])
 print('UI actuals:',json.dumps(f['logbook_first_match_projection']))
 print('PIREP:',json.dumps([e['detail'] for e in f['events'] if e['kind']=='pirep_submitted']))
print('JOURNAL MATCH:',json.dumps({k:v for k,v in result['tracking_comparison'].items() if k!='matches'}))
print('FROZEN SOURCE',json.dumps(result['frozen_source']))
