"""Reconstruct supplied native JST500 evidence; never opens the installed profile."""
from pathlib import Path
from datetime import datetime
from collections import Counter
import json, math, gzip, csv, hashlib, re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
BASE=HERE/'extracted/S4 - FINAL T2 DESTINATION VALIDATION'
JOURNAL=next((BASE/'01-after-submit-before-restart').glob('*.jsonl'))
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def at(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
def ticks(s):
    match=re.fullmatch(r'(.*?)(?:\.(\d+))?(Z|[+-]\d\d:\d\d)',s)
    base,fraction,zone=match.groups()
    return int(at(base+zone).timestamp())*10_000_000+int((fraction or '').ljust(7,'0')[:7])
def seconds(a,b,key='simulatorUtc'): return (ticks(b[key])-ticks(a[key]))/10_000_000
def loc(r): return {k:r[k] for k in ('sequence','kind','recordedAtUtc','simulatorUtc')}
def point(r): return {**loc(r),'detail':r['detail']}
def nm(lat,lon,lat2,lon2):
    a,b,c,d=map(math.radians,(lat,lon,lat2,lon2))
    h=math.sin((c-a)/2)**2+math.cos(a)*math.cos(c)*math.sin((d-b)/2)**2
    return 3440.065*2*math.atan2(math.sqrt(h),math.sqrt(1-h))
raw=JOURNAL.read_bytes(); lines=raw.decode('utf-8-sig').splitlines(); malformed=[]; rows=[]
for i,line in enumerate(lines,1):
    try: rows.append(json.loads(line))
    except json.JSONDecodeError as e: malformed.append({'line':i,'error':str(e)})
export=read(JOURNAL.with_suffix('.json'))
telemetry=[r for r in rows if r['kind']=='telemetry']
states=[r for r in rows if r['kind']=='tracking_state']
events=[r for r in rows if r['kind']=='tracking_event']
milestones=[r for r in rows if r['kind']=='flight_milestone']
policy=[r for r in rows if r['kind']=='terminal_block_in']
assignment=next(r for r in rows if r['kind']=='flight_assignment')
def first_title(title): return next(r for r in events if r['detail']['Title']==title)
on=next(r for r in milestones if r['detail']['phase']=='TaxiIn')
landed=[r for r in telemetry if at(r['simulatorUtc'])>=at(on['simulatorUtc'])]
cut=[next(r for r in landed if r['detail']['terminalShutdown']['Engines'][i]['Cutoff'] is True) for i in (0,1)]
off=[next(r for r in landed if r['detail']['terminalShutdown']['Engines'][i]['Combustion'] is False) for i in (0,1)]
verified=next(r for r in policy if r['detail']['decision']['Reason']=='Verified terminal shutdown')
complete=next(r for r in states if r['detail']['phase']=='Complete')
in_milestone=next(r for r in milestones if r['detail']['phase']=='Complete')
sample_for=lambda r: next(t for t in telemetry if t['simulatorUtc']==r['simulatorUtc'])
confirm_sample=sample_for(verified); complete_sample=sample_for(complete)
park_index=next(i for i,t in enumerate(telemetry) if t['sequence']==cut[0]['sequence'])
def parked(r):
    d=r['detail'];return d['onGround'] and d['parkingBrake'] and math.isfinite(d['groundSpeedKnots']) and 0<=d['groundSpeedKnots']<.5 and not d['paused'] and not d['slewing']
while park_index>0 and parked(telemetry[park_index-1]) and at(telemetry[park_index-1]['simulatorUtc'])>=at(on['simulatorUtc']):park_index-=1
park=telemetry[park_index]
both=[t for t in telemetry if park['sequence']<=t['sequence']<cut[0]['sequence']]
single=[t for t in telemetry if cut[0]['sequence']<=t['sequence']<cut[1]['sequence']]
terminal=[t for t in telemetry if park['sequence']<=t['sequence']<=complete['sequence']]
qualified=[t for t in telemetry if t['detail']['terminalShutdown']['Qualified']]
def coherent(t):
    e=t['detail']['terminalShutdown']; now=t['recordedAtUtc']
    return e['Valid'] and e['Qualified'] and e['ExpectedEngineCount']==2 and len(e['Engines'])==2 and sorted(x['Index'] for x in e['Engines'])==[1,2] and all(x['Cutoff'] is not None and x['Combustion'] is not None and 0<=(at(now)-at(x['ReceivedUtc'])).total_seconds()<=3 for x in e['Engines'])
def operating_engine(t,i):
    e=t['detail']['terminalShutdown']['Engines'][i];return e['Cutoff'] is False and e['Combustion'] is True
sim_gaps=[seconds(a,b) for a,b in zip(telemetry,telemetry[1:])]
wall_gaps=[seconds(a,b,'recordedAtUtc') for a,b in zip(telemetry,telemetry[1:])]
state_transitions=[]
previous=None
for s in states:
    if s['detail']['phase']!=previous:state_transitions.append(point(s));previous=s['detail']['phase']
airport_file=ROOT/'assets/airports/airports.tsv.gz'
airport=next(line.split('\t') for line in gzip.decompress(airport_file.read_bytes()).decode('utf-8').splitlines() if line.startswith('YSSY\t'))
lat,lon=map(float,airport[3:5]); c=complete_sample['detail']
dist=nm(c['latitude'],c['longitude'],lat,lon)
timeline=[rows[0],assignment,next(r for r in rows if r['kind']=='connection_opened'),next(r for r in rows if r['kind']=='monitor_armed')]
timeline += [r for r in milestones if r['detail']['phase']!='Complete']
timeline += [first_title(t) for t in ['Initial climb','Top of climb / cruise established','Top of descent','Taxi-in']]
timeline += [park,cut[0],off[0],cut[1],off[1],verified,in_milestone,complete,next(r for r in rows if r['kind']=='pirep_closeout_complete'),rows[-1]]
result={
 'journal':str(JOURNAL),'journalSha256':hashlib.sha256(raw).hexdigest().upper(),
 'totalRecords':len(rows),'telemetrySamples':len(telemetry),'trackingStateCount':len(states),
 'malformedLines':malformed,'endsWithNewline':raw.endswith(b'\n'),'exportMetadata':{k:v for k,v in export.items() if k!='events'},
 'exportMatchesJournal':export['events']==rows,'contiguousSequences':[r['sequence'] for r in rows]==list(range(1,len(rows)+1)),
 'kinds':dict(Counter(r['kind'] for r in rows)),
 'firstTelemetry':point(telemetry[0]),'lastTelemetry':point(telemetry[-1]),'assignment':assignment,
 'timeline':sorted([point(r) for r in timeline],key=lambda r:r['sequence']),
 'milestones':[point(r) for r in milestones],'trackingEvents':[point(r) for r in events],
 'stateTransitions':state_transitions,'policyEvents':policy,
 'terminal':{'parking':point(park),'engineCutoffs':[point(r) for r in cut],'combustionOff':[point(r) for r in off],
             'verifiedEvidence':point(verified),'verifiedSample':point(confirm_sample),'completeSample':point(complete_sample),
             'completeState':point(complete),'effectiveIn':point(in_milestone),
             'bothRunningHoldSeconds':seconds(park,cut[0]),'bothRunningHoldSamples':len(both),
             'singleEngineHoldSeconds':seconds(cut[0],cut[1]),'singleEngineCombustionOffHoldSeconds':seconds(off[0],cut[1]),'singleEngineHoldSamples':len(single),
             'cutoffToCombustionSeconds':[seconds(a,b) for a,b in zip(cut,off)],
             'combustionToVerifiedSeconds':seconds(off[1],verified),'verifiedToEffectiveInSeconds':seconds(verified,in_milestone),
             'verifiedToCompleteSeconds':seconds(verified,complete),'cutoffToCompleteSeconds':seconds(cut[1],complete),
             'verifiedToCompletePublicationWallSeconds':seconds(verified,in_milestone,'recordedAtUtc'),
             'cutoffToCompletePublicationWallSeconds':seconds(cut[1],in_milestone,'recordedAtUtc'),
             'completeMilestoneToTrackingStateWallSeconds':seconds(in_milestone,complete,'recordedAtUtc'),
             'finalPosition':{'latitude':c['latitude'],'longitude':c['longitude']},
             'airportReference':{'file':str(airport_file),'code':airport[0],'latitude':lat,'longitude':lon},'distanceNm':dist,
             'maxGroundSpeedKnotsDuringHolds':max(t['detail']['groundSpeedKnots'] for t in terminal),
             'genericConditionsAtComplete':c['engineStates']},
 'adapter':{'providers':dict(Counter(t['detail']['terminalShutdown']['Provider'] for t in telemetry)),
            'connectionIds':sorted(set(t['detail']['terminalShutdown']['ConnectionId'] for t in telemetry)),
            'expectedCounts':dict(Counter(t['detail']['terminalShutdown']['ExpectedEngineCount'] for t in telemetry)),
            'validCount':sum(t['detail']['terminalShutdown']['Valid'] for t in telemetry),
            'qualifiedCount':len(qualified),'firstQualified':point(qualified[0]),
            'qualifiedMaxEngineAgeSeconds':max((at(t['recordedAtUtc'])-at(e['ReceivedUtc'])).total_seconds() for t in qualified for e in t['detail']['terminalShutdown']['Engines'])},
 'integrity':{'wallGapMinSeconds':min(wall_gaps),'wallGapMaxSeconds':max(wall_gaps),'simGapMinSeconds':min(sim_gaps),'simGapMaxSeconds':max(sim_gaps),
              'allRecordsWallOutOfOrder':sum(seconds(a,b,'recordedAtUtc')<0 for a,b in zip(rows,rows[1:])),
              'missingSampleFields':sum(any(k not in t['detail'] for k in ['latitude','longitude','groundSpeedKnots','onGround','parkingBrake','paused','slewing','engineReadings','engineStates','terminalShutdown']) for t in telemetry),
              'nonFinitePositionOrSpeedSamples':sum(not all(isinstance(t['detail'].get(k),(int,float)) and math.isfinite(t['detail'][k]) for k in ['latitude','longitude','groundSpeedKnots']) for t in telemetry),
              'loggedErrorKinds':[r for r in rows if re.search('error|exception|failed|fault',r['kind'],re.I)],
              'wallGapsOver2Seconds':[{**loc(b),'gapSeconds':g} for a,b,g in zip(telemetry,telemetry[1:],wall_gaps) if g>2],
              'simGapsOver2Seconds':[{**loc(b),'gapSeconds':g} for a,b,g in zip(telemetry,telemetry[1:],sim_gaps) if g>2],
              'wallOutOfOrder':sum(g<=0 for g in wall_gaps),'simOutOfOrder':sum(g<=0 for g in sim_gaps),
              'pausedSamples':sum(t['detail']['paused'] for t in telemetry),'slewingSamples':sum(t['detail']['slewing'] for t in telemetry),
              'duplicateTrackingEvents':len(events)-len({(e['simulatorUtc'],json.dumps(e['detail'],sort_keys=True)) for e in events}),
              'genericEngineDataInvalidSamples':sum(not t['detail']['engineDataValid'] for t in telemetry)},
 'progress':{'preCompleteMax':max(s['detail']['progress'] or 0 for s in states if s['detail']['phase']!='Complete'),
             'premature100Samples':sum(s['detail']['phase']!='Complete' and (s['detail']['progress'] or 0)>=1 for s in states),
             'taxiInExpiredEtas':sum(s['detail']['phase']=='TaxiIn' and s['detail']['estimatedIn'] is not None and at(s['detail']['estimatedIn'])<at(s['simulatorUtc']) for s in states)},
}
precomplete=[s for s in states if s['sequence']<verified['sequence']]
checks={
 'matchingCompleteRepresentations':result['exportMatchesJournal'] and export['sessionEnded'] and not export['incompleteLastLine'] and not malformed,
 'contiguousJournalSequence':result['contiguousSequences'],
 'oneConnectionOneAssignment':result['kinds'].get('connection_opened')==1 and result['kinds'].get('flight_assignment')==1,
 'oneOrderedOOOI':[m['detail']['phase'] for m in milestones]==['TaxiOut','Airborne','TaxiIn','Complete'] and all(seconds(a,b)>0 for a,b in zip(milestones,milestones[1:])),
 'oneCompleteTransition':sum(s['detail']['phase']=='Complete' for s in state_transitions)==1,
 'bothEngineRunningHoldAtLeast15Seconds':seconds(park,cut[0])>=15 and all(parked(t) and operating_engine(t,0) and operating_engine(t,1) for t in both),
 'singleEngineHoldAtLeast20Seconds':seconds(cut[0],cut[1])>=20 and all(parked(t) and t['detail']['terminalShutdown']['Engines'][0]['Cutoff'] is True and operating_engine(t,1) for t in single),
 'noPrematureEligibilityOrComplete':all(not s['detail']['TerminalBlockInEligible'] and s['detail']['phase']!='Complete' for s in precomplete),
 'automaticNoManualAuthority':not any('confirmation' in r['kind'] for r in rows) and all(not s['detail']['PilotConfirmedBlockIn'] for s in states) and verified['detail']['decision']['TerminalEligible'] and not verified['detail']['decision']['PilotConfirmed'],
 'guardsAtVerified':all(verified['detail'][key] for key in ['HasOn','AtDestination','SessionValid']) and parked(confirm_sample) and coherent(confirm_sample) and dist<5,
 'allOffEvidenceAtVerified':all(e['Cutoff'] is True and e['Combustion'] is False for e in confirm_sample['detail']['terminalShutdown']['Engines']),
 'stableEvidenceUntilComplete':seconds(verified,complete)>=3 and all(parked(t) and coherent(t) and all(e['Cutoff'] is True and e['Combustion'] is False for e in t['detail']['terminalShutdown']['Engines']) for t in telemetry if confirm_sample['sequence']<=t['sequence']<=complete_sample['sequence']),
 'mechanicalSpoolDownNotRequired':c['engineReadings'][1]['N2Percent']>40 and c['engineStates'][1]['Condition']==4,
 'oneCloseoutAndPirepEnded':result['kinds'].get('pirep_closeout_complete')==1 and rows[-1]['kind']=='session_ended' and rows[-1]['detail']['reason']=='pirep_submitted',
 'noDisconnectPauseSlewOrOutOfOrder':len(result['adapter']['connectionIds'])==1 and all(result['integrity'][k]==0 for k in ['wallOutOfOrder','simOutOfOrder','pausedSamples','slewingSamples']),
 'noDuplicateTrackingEvents':result['integrity']['duplicateTrackingEvents']==0,
 'noPremature100':result['progress']['premature100Samples']==0,
 'noExpiredTaxiInEta':result['progress']['taxiInExpiredEtas']==0,
}
result['checks']=checks
(HERE/'flight-analysis.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
with (HERE/'terminal-telemetry.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['seq','simulatorUtc','recordedUtc','cutoff1','combustion1','cutoff2','combustion2','qualified','genericValid','N1_1','N2_1','fuelPph1','N1_2','N2_2','fuelPph2','phase'])
    last_phase='AtGate'
    phase_by_time={s['simulatorUtc']:s['detail']['phase'] for s in states}
    for t in landed:
        d=t['detail'];e=d['terminalShutdown']['Engines'];p=d['engineReadings'];w.writerow([t['sequence'],t['simulatorUtc'],t['recordedAtUtc'],e[0]['Cutoff'],e[0]['Combustion'],e[1]['Cutoff'],e[1]['Combustion'],d['terminalShutdown']['Qualified'],d['engineDataValid'],p[0]['N1Percent'],p[0]['N2Percent'],p[0]['FuelFlowPph'],p[1]['N1Percent'],p[1]['N2Percent'],p[1]['FuelFlowPph'],phase_by_time.get(t['simulatorUtc'])])
print(json.dumps({'records':len(rows),'samples':len(telemetry),'checks':checks,'integrity':result['integrity'],'progress':result['progress'],'terminalMetrics':{k:v for k,v in result['terminal'].items() if k.endswith(('Seconds','Samples')) or k in ['distanceNm','finalPosition']},'qualification':{k:v for k,v in result['adapter'].items() if k!='firstQualified'}},indent=2))
